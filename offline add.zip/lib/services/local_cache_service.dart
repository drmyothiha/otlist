import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class LocalCacheService {
  static const String _cacheKey = 'operations_cache';

  // Save operation locally
  static Future<void> saveOperation(Map<String, Object> operation) async {
    final prefs = await SharedPreferences.getInstance();
    final cachedOperations = prefs.getStringList(_cacheKey) ?? [];
    cachedOperations.add(jsonEncode(operation));
    await prefs.setStringList(_cacheKey, cachedOperations);
  }

static Future<List<Map<String, Object>>> getCachedOperations() async {
  final prefs = await SharedPreferences.getInstance();
  final cachedOperations = prefs.getStringList(_cacheKey) ?? [];

  return cachedOperations.map((operation) {
    return (jsonDecode(operation) as Map<String, dynamic>).cast<String, Object>();
  }).toList();
}


  // Remove operation from cache
static Future<void> removeOperation(Map<String, dynamic> operation) async {
  final prefs = await SharedPreferences.getInstance();
  final cached = prefs.getStringList(_cacheKey) ?? [];

  final updated = cached.where((item) {
    final decoded = jsonDecode(item);
    return !(decoded['title'] == operation['title'] &&
             decoded['details'] == operation['details'] &&
             decoded['created_at'] == operation['created_at']);
  }).toList();

  await prefs.setStringList(_cacheKey, updated);
}


  // Clear all cached operations
  static Future<void> clearCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_cacheKey);
  }
}
