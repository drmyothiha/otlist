import 'package:flutter/material.dart';
import 'package:modern_auth_app/services/auth_service.dart';
import 'login_screen.dart'; // Import to navigate back after logout
import 'add_operation_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert'; // for jsonEncode and jsonDecode
import 'package:internet_connection_checker/internet_connection_checker.dart';
import '../services/local_cache_service.dart'; // Import your cache service

class OperationsScreen extends StatefulWidget {
  final String token;

  const OperationsScreen({super.key, required this.token});

  @override
  _OperationsScreenState createState() => _OperationsScreenState();
}

class _OperationsScreenState extends State<OperationsScreen> {
  late Future<List<dynamic>> _operations;

  @override
  void initState() {
    super.initState();
    _operations = _fetchOperations();
  }

  Future<List<dynamic>> _fetchOperations() async {
    final authService = AuthService();
    final prefs = await SharedPreferences.getInstance();

    try {
      final data = await authService.fetchOperations(widget.token);

      // Cache successful result
      await prefs.setString('cached_operations', jsonEncode(data));

      return data;
    } catch (e) {
      // Network/server failed → Try offline cache
      final cached = prefs.getString('cached_operations');
      if (cached != null) {
        return jsonDecode(cached);
      } else {
        // No internet + no cache
        throw Exception('Unable to load data. Please check your internet connection.');
      }
    }
  }

Future<void> _refreshOperations() async {
  // Sync offline operations before refreshing the operations list
  await _syncOfflineOperations();
  
  // Refresh the list of operations from the server or local cache
  setState(() {
    _operations = _fetchOperations();
  });
}

Future<void> _syncOfflineOperations() async {
  // Check internet connection first
  if (!await InternetConnectionChecker().hasConnection) return;

  final unsyncedOps = await LocalCacheService.getCachedOperations();
  if (unsyncedOps.isEmpty) return;

  bool anySyncFailed = false;
  int successfulSyncs = 0;

  for (final op in unsyncedOps) {
    // Check connection before each operation
    if (!await InternetConnectionChecker().hasConnection) {
      anySyncFailed = true;
      debugPrint("⏸️ Sync paused - lost internet connection");
      break; // Exit the loop if connection is lost
    }

    // Try to sync the operation
    final success = await AuthService().addOperation(
      widget.token,
      op['title'] as String,
      op['details'] as String,
    );

    if (success) {
      // Remove from cache if successful
      await LocalCacheService.removeOperation(op);
      successfulSyncs++;
    } else {
      anySyncFailed = true;
      debugPrint("❌ Failed to sync operation: ${op['title']}");
    }
  }

  if (!mounted) return;

  // Show appropriate status message
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        anySyncFailed
          ? 'Synced $successfulSyncs operations (some failed)'
          : 'Successfully synced $successfulSyncs operations',
      ),
      duration: const Duration(seconds: 2),
    ),
  );
}

  void _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token'); // remove token

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (route) => false,
    );
  }

void _navigateToAddOperation() async {
  final result = await Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => AddOperationScreen(
        token: widget.token, // Pass the token here
        onOperationAdded: (title, details) async {
          final authService = AuthService();
          await authService.addOperation(widget.token, title, details);

          await _refreshOperations();
        },
      ),
    ),
  );

  if (result == true) {
    _refreshOperations(); // Reload after adding
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Operations"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Logout',
          )
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshOperations, // Trigger sync and refresh here
        child: FutureBuilder<List<dynamic>>(
          future: _operations,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No operations found.'));
            }

            final operations = snapshot.data!;

            return ListView.builder(
              itemCount: operations.length,
              itemBuilder: (context, index) {
                final operation = operations[index];
                return ListTile(
                  title: Text(operation['title']),
                  subtitle: Text(operation['details']),
                  trailing: Text(operation['created_at']),
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddOperation,
        tooltip: 'Add Operation',
        child: const Icon(Icons.add),
      ),
    );
  }
}
