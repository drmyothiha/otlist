import 'package:flutter/material.dart';
import 'package:modern_auth_app/services/auth_service.dart';
import 'login_screen.dart'; // Import to navigate back after logout

class OperationsScreen extends StatefulWidget {
  final String token;

  const OperationsScreen({Key? key, required this.token}) : super(key: key);

  @override
  _OperationsScreenState createState() => _OperationsScreenState();
}

class _OperationsScreenState extends State<OperationsScreen> {
  late Future<List<dynamic>> _operations;

  @override
  void initState() {
    super.initState();
    _operations = _fetchOperations();
  }

  Future<List<dynamic>> _fetchOperations() async {
    final authService = AuthService();
    return await authService.fetchOperations(widget.token);
  }

  Future<void> _refreshOperations() async {
    setState(() {
      _operations = _fetchOperations();
    });
  }

  void _logout() {
    // Optionally clear token from local storage if you're saving it
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Operations"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Logout',
          )
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshOperations,
        child: FutureBuilder<List<dynamic>>(
          future: _operations,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No operations found.'));
            }

            final operations = snapshot.data!;

            return ListView.builder(
              itemCount: operations.length,
              itemBuilder: (context, index) {
                final operation = operations[index];
                return ListTile(
                  title: Text(operation['title']),
                  subtitle: Text(operation['details']),
                  trailing: Text(operation['created_at']),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
